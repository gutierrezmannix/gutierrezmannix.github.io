/* @ds-bundle: {"format":3,"namespace":"SenderoDesignSystem_139929","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"SearchField","sourcePath":"components/forms/SearchField.jsx"},{"name":"SegmentedControl","sourcePath":"components/forms/SegmentedControl.jsx"},{"name":"BottomNav","sourcePath":"components/navigation/BottomNav.jsx"},{"name":"DifficultyPill","sourcePath":"components/trail/DifficultyPill.jsx"},{"name":"TrailCard","sourcePath":"components/trail/TrailCard.jsx"},{"name":"TrailStats","sourcePath":"components/trail/TrailStats.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"4ba4d085549d","components/core/Button.jsx":"b45630148250","components/core/Card.jsx":"719a2d740dff","components/core/IconButton.jsx":"09eb3bb840db","components/core/Tag.jsx":"884fa3c0e1a9","components/forms/Input.jsx":"ebaf6caaeb2e","components/forms/SearchField.jsx":"e75a70d770fe","components/forms/SegmentedControl.jsx":"1479be16f91b","components/navigation/BottomNav.jsx":"2d69584066d3","components/trail/DifficultyPill.jsx":"3aa25ffee734","components/trail/TrailCard.jsx":"7dd69a3cc65f","components/trail/TrailStats.jsx":"6391278e32bd","ui_kits/app/MapCanvas.jsx":"361f7031bc4b","ui_kits/app/data.js":"75fba3c03243","ui_kits/app/ios-frame.jsx":"be3343be4b51","ui_kits/app/screens.jsx":"e6acaaf41265"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SenderoDesignSystem_139929 = window.SenderoDesignSystem_139929 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: {
    bg: 'var(--arena-100)',
    fg: 'var(--arena-700)'
  },
  brand: {
    bg: 'var(--brand-soft)',
    fg: 'var(--verde-700)'
  },
  accent: {
    bg: 'var(--toronja-50)',
    fg: 'var(--toronja-700)'
  },
  success: {
    bg: 'var(--success-soft)',
    fg: 'var(--verde-700)'
  },
  warning: {
    bg: 'var(--warning-soft)',
    fg: 'var(--toronja-700)'
  },
  danger: {
    bg: 'var(--danger-soft)',
    fg: 'var(--red-700)'
  },
  info: {
    bg: 'var(--info-soft)',
    fg: 'var(--resaca-700)'
  },
  water: {
    bg: 'var(--resaca-100)',
    fg: 'var(--resaca-700)'
  }
};

/** Small status pill — open/closed, "Bird hotspot", advisory counts, etc. */
function Badge({
  tone = 'neutral',
  size = 'md',
  dot = false,
  children,
  style = {},
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: sm ? '2px 8px' : '4px 10px',
      borderRadius: 'var(--radius-pill)',
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: sm ? 11 : 12,
      lineHeight: 1.4,
      letterSpacing: '0.01em',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: t.fg,
      flex: 'none'
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    padding: '0 14px',
    height: 36,
    fontSize: 14,
    gap: 7,
    radius: 'var(--radius-sm)'
  },
  md: {
    padding: '0 18px',
    height: 44,
    fontSize: 15,
    gap: 8,
    radius: 'var(--radius-md)'
  },
  lg: {
    padding: '0 24px',
    height: 52,
    fontSize: 16,
    gap: 10,
    radius: 'var(--radius-md)'
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--brand)',
    color: 'var(--text-on-brand)',
    border: '1.5px solid transparent',
    boxShadow: 'var(--shadow-xs)',
    hover: {
      background: 'var(--brand-hover)'
    }
  },
  accent: {
    background: 'var(--accent)',
    color: 'var(--toronja-900)',
    border: '1.5px solid transparent',
    boxShadow: 'var(--shadow-xs)',
    hover: {
      background: 'var(--accent-hover)',
      color: '#fff'
    }
  },
  secondary: {
    background: 'var(--surface-card)',
    color: 'var(--text-strong)',
    border: '1.5px solid var(--border)',
    boxShadow: 'var(--shadow-xs)',
    hover: {
      background: 'var(--arena-50)',
      borderColor: 'var(--border-strong)'
    }
  },
  ghost: {
    background: 'transparent',
    color: 'var(--brand)',
    border: '1.5px solid transparent',
    boxShadow: 'none',
    hover: {
      background: 'var(--brand-soft)'
    }
  },
  danger: {
    background: 'var(--danger)',
    color: '#fff',
    border: '1.5px solid transparent',
    boxShadow: 'var(--shadow-xs)',
    hover: {
      background: 'var(--red-700)'
    }
  }
};

/**
 * Sendero primary button. Brand-green by default; amber `accent` for the
 * single most important action on a screen.
 */
function Button({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  leadingIcon = null,
  trailingIcon = null,
  as = 'button',
  children,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  const Tag = as;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    height: s.height,
    padding: s.padding,
    borderRadius: s.radius,
    fontFamily: 'var(--font-sans)',
    fontWeight: 600,
    fontSize: s.fontSize,
    lineHeight: 1,
    letterSpacing: '-0.01em',
    textDecoration: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    width: fullWidth ? '100%' : 'auto',
    transition: 'background var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)',
    background: v.background,
    color: v.color,
    border: v.border,
    boxShadow: v.boxShadow,
    opacity: disabled ? 0.5 : 1,
    transform: hover && !disabled ? 'translateY(-1px)' : 'none',
    ...(hover && !disabled ? v.hover : {}),
    ...style
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: base,
    disabled: as === 'button' ? disabled : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest), leadingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flex: 'none'
    }
  }, leadingIcon), children, trailingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flex: 'none'
    }
  }, trailingIcon));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Surface container. The base building block for lists, sheets and panels. */
function Card({
  as = 'div',
  interactive = false,
  padding = 'md',
  elevation = 'sm',
  children,
  style = {},
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const Tag = as;
  const pad = {
    none: 0,
    sm: 'var(--space-3)',
    md: 'var(--space-5)',
    lg: 'var(--space-6)'
  }[padding] ?? 'var(--space-5)';
  const shadow = {
    none: 'none',
    sm: 'var(--shadow-sm)',
    md: 'var(--shadow-md)',
    lg: 'var(--shadow-lg)'
  }[elevation] ?? 'var(--shadow-sm)';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'block',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-soft)',
      borderRadius: 'var(--radius-lg)',
      padding: pad,
      boxShadow: interactive && hover ? 'var(--shadow-card-hover)' : shadow,
      cursor: interactive ? 'pointer' : 'default',
      transform: interactive && hover ? 'translateY(-2px)' : 'none',
      transition: 'box-shadow var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: 32,
  md: 40,
  lg: 48
};
const VARIANTS = {
  solid: {
    background: 'var(--brand)',
    color: '#fff',
    border: '1.5px solid transparent',
    hover: {
      background: 'var(--brand-hover)'
    }
  },
  soft: {
    background: 'var(--brand-soft)',
    color: 'var(--brand)',
    border: '1.5px solid transparent',
    hover: {
      background: 'var(--verde-100)'
    }
  },
  outline: {
    background: 'var(--surface-card)',
    color: 'var(--text-body)',
    border: '1.5px solid var(--border)',
    hover: {
      background: 'var(--arena-50)',
      borderColor: 'var(--border-strong)'
    }
  },
  ghost: {
    background: 'transparent',
    color: 'var(--text-muted)',
    border: '1.5px solid transparent',
    hover: {
      background: 'var(--arena-100)',
      color: 'var(--text-strong)'
    }
  },
  float: {
    background: 'var(--surface-card)',
    color: 'var(--text-strong)',
    border: '1.5px solid transparent',
    boxShadow: 'var(--shadow-float)',
    hover: {
      background: 'var(--arena-50)'
    }
  }
};

/** Square icon-only button. Used for map controls, toolbars and the FAB. */
function IconButton({
  variant = 'soft',
  size = 'md',
  disabled = false,
  label,
  round = false,
  children,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const dim = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.soft;
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": label,
    title: label,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: dim,
      height: dim,
      flex: 'none',
      padding: 0,
      borderRadius: round ? 'var(--radius-pill)' : 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      background: v.background,
      color: v.color,
      border: v.border,
      boxShadow: v.boxShadow || 'none',
      opacity: disabled ? 0.5 : 1,
      transition: 'background var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)',
      ...(hover && !disabled ? v.hover : {}),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Outlined chip for filters, amenities and trail attributes. Becomes a toggle
 * when `selected`/`onClick` are supplied, and removable when `onRemove` is set.
 */
function Tag({
  selected = false,
  icon = null,
  onRemove = null,
  children,
  style = {},
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!onClick;
  return /*#__PURE__*/React.createElement("span", _extends({
    role: interactive ? 'button' : undefined,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '5px 12px',
      borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 13,
      lineHeight: 1.3,
      cursor: interactive ? 'pointer' : 'default',
      userSelect: 'none',
      border: '1.5px solid',
      borderColor: selected ? 'var(--brand)' : hover && interactive ? 'var(--border-strong)' : 'var(--border)',
      background: selected ? 'var(--brand-soft)' : 'var(--surface-card)',
      color: selected ? 'var(--verde-700)' : 'var(--text-body)',
      transition: 'all var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flex: 'none',
      opacity: 0.85
    }
  }, icon), children, onRemove && /*#__PURE__*/React.createElement("span", {
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    style: {
      display: 'inline-flex',
      marginRight: -4,
      marginLeft: 2,
      opacity: 0.55,
      cursor: 'pointer',
      fontSize: 14,
      lineHeight: 1
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Text field with optional leading icon, label and helper/error text. */
function Input({
  label,
  helper,
  error,
  leadingIcon = null,
  trailingIcon = null,
  size = 'md',
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || React.useId();
  const h = size === 'sm' ? 38 : size === 'lg' ? 52 : 44;
  const borderColor = error ? 'var(--danger)' : focus ? 'var(--brand)' : 'var(--border)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fid,
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-strong)',
      fontFamily: 'var(--font-sans)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      height: h,
      padding: '0 14px',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      border: `1.5px solid ${borderColor}`,
      boxShadow: focus ? 'var(--ring)' : 'none',
      transition: 'border-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)'
    }
  }, leadingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flex: 'none',
      color: 'var(--text-muted)'
    }
  }, leadingIcon), /*#__PURE__*/React.createElement("input", _extends({
    id: fid,
    onFocus: e => {
      setFocus(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocus(false);
      rest.onBlur && rest.onBlur(e);
    }
  }, rest, {
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: size === 'sm' ? 14 : 15,
      color: 'var(--text-strong)',
      padding: 0
    }
  })), trailingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flex: 'none',
      color: 'var(--text-muted)'
    }
  }, trailingIcon)), (helper || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: error ? 'var(--danger)' : 'var(--text-muted)',
      fontFamily: 'var(--font-sans)'
    }
  }, error || helper));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/SearchField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Rounded search bar for finding parks & trails. Pill-shaped, elevated. */
function SearchField({
  value,
  onChange,
  placeholder = 'Search parks & trails',
  onClear,
  elevated = true,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: 48,
      padding: '0 16px',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-pill)',
      border: `1.5px solid ${focus ? 'var(--brand)' : 'var(--border-soft)'}`,
      boxShadow: elevated ? 'var(--shadow-float)' : 'none',
      transition: 'border-color var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "search",
    style: {
      width: 18,
      height: 18,
      color: 'var(--text-muted)',
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false)
  }, rest, {
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: 15,
      color: 'var(--text-strong)'
    }
  })), value ? /*#__PURE__*/React.createElement("button", {
    onClick: onClear,
    "aria-label": "Clear",
    style: {
      display: 'inline-flex',
      border: 'none',
      background: 'var(--arena-100)',
      borderRadius: '50%',
      width: 22,
      height: 22,
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      color: 'var(--text-muted)',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "x",
    style: {
      width: 13,
      height: 13
    }
  })) : /*#__PURE__*/React.createElement("i", {
    "data-lucide": "sliders-horizontal",
    style: {
      width: 17,
      height: 17,
      color: 'var(--text-muted)',
      flex: 'none'
    }
  }));
}
Object.assign(__ds_scope, { SearchField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SearchField.jsx", error: String((e && e.message) || e) }); }

// components/forms/SegmentedControl.jsx
try { (() => {
/** Segmented control for switching views (Map / List) or short filter sets. */
function SegmentedControl({
  options = [],
  value,
  onChange,
  size = 'md',
  style = {}
}) {
  const h = size === 'sm' ? 34 : 40;
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: 'inline-flex',
      padding: 3,
      gap: 2,
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--border-soft)',
      ...style
    }
  }, options.map(opt => {
    const val = typeof opt === 'string' ? opt : opt.value;
    const label = typeof opt === 'string' ? opt : opt.label;
    const icon = typeof opt === 'string' ? null : opt.icon;
    const active = val === value;
    return /*#__PURE__*/React.createElement("button", {
      key: val,
      role: "tab",
      "aria-selected": active,
      onClick: () => onChange && onChange(val),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: h,
        padding: '0 16px',
        border: 'none',
        borderRadius: 'var(--radius-pill)',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)',
        fontWeight: 600,
        fontSize: size === 'sm' ? 13 : 14,
        background: active ? 'var(--surface-card)' : 'transparent',
        color: active ? 'var(--text-strong)' : 'var(--text-muted)',
        boxShadow: active ? 'var(--shadow-xs)' : 'none',
        transition: 'background var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)'
      }
    }, icon && /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        flex: 'none'
      }
    }, icon), label);
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/navigation/BottomNav.jsx
try { (() => {
/**
 * Mobile bottom tab bar. Items: {value, label, icon}. The active tab is
 * tinted brand-green; everything else is muted.
 */
function BottomNav({
  items = [],
  value,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'stretch',
      justifyContent: 'space-around',
      background: 'var(--surface-card)',
      borderTop: '1px solid var(--border-soft)',
      padding: '8px 6px calc(8px + env(safe-area-inset-bottom, 0px))',
      boxShadow: '0 -2px 12px rgba(43,39,30,0.05)',
      ...style
    }
  }, items.map(it => {
    const active = it.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      onClick: () => onChange && onChange(it.value),
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        flex: 1,
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        padding: '4px 0',
        minHeight: 'var(--tap-min)',
        color: active ? 'var(--brand)' : 'var(--text-subtle)',
        transition: 'color var(--dur-fast) var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex'
      }
    }, it.icon), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 11,
        fontWeight: active ? 700 : 500,
        letterSpacing: '0.01em'
      }
    }, it.label));
  }));
}
Object.assign(__ds_scope, { BottomNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/BottomNav.jsx", error: String((e && e.message) || e) }); }

// components/trail/DifficultyPill.jsx
try { (() => {
const LEVELS = {
  easy: {
    label: 'Easy',
    color: 'var(--diff-easy)',
    soft: 'var(--diff-easy-soft)',
    bars: 1
  },
  moderate: {
    label: 'Moderate',
    color: 'var(--diff-moderate)',
    soft: 'var(--diff-moderate-soft)',
    bars: 2
  },
  hard: {
    label: 'Hard',
    color: 'var(--diff-hard)',
    soft: 'var(--diff-hard-soft)',
    bars: 3
  },
  expert: {
    label: 'Expert',
    color: 'var(--diff-expert)',
    soft: 'var(--diff-expert-soft)',
    bars: 4
  }
};

/** Trail difficulty indicator with a 4-bar level meter. Domain-semantic colors. */
function DifficultyPill({
  level = 'easy',
  showBars = true,
  size = 'md',
  style = {}
}) {
  const l = LEVELS[level] || LEVELS.easy;
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      padding: sm ? '3px 9px 3px 8px' : '4px 11px 4px 9px',
      borderRadius: 'var(--radius-pill)',
      background: l.soft,
      color: l.color,
      fontFamily: 'var(--font-sans)',
      fontWeight: 700,
      fontSize: sm ? 11 : 12.5,
      lineHeight: 1,
      whiteSpace: 'nowrap',
      ...style
    }
  }, showBars && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'flex-end',
      gap: 1.5,
      height: sm ? 9 : 11
    }
  }, [0, 1, 2, 3].map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: sm ? 2.5 : 3,
      borderRadius: 1,
      height: `${40 + i * 20}%`,
      background: i < l.bars ? l.color : 'currentColor',
      opacity: i < l.bars ? 1 : 0.25
    }
  }))), l.label);
}
Object.assign(__ds_scope, { DifficultyPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trail/DifficultyPill.jsx", error: String((e && e.message) || e) }); }

// components/trail/TrailStats.jsx
try { (() => {
/**
 * Horizontal row of trail metrics (distance, elevation, time, etc.) rendered
 * in the mono "field-survey" style. Pass an array of {icon,value,label}.
 */
function TrailStats({
  stats = [],
  size = 'md',
  style = {}
}) {
  const big = size === 'lg';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: big ? 28 : 18,
      flexWrap: 'wrap',
      ...style
    }
  }, stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--text-strong)'
    }
  }, s.icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      color: 'var(--text-muted)',
      flex: 'none'
    }
  }, s.icon), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: big ? 22 : 16,
      fontVariantNumeric: 'tabular-nums',
      letterSpacing: '-0.01em',
      lineHeight: 1.1
    }
  }, s.value)), s.label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 11,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: '0.08em',
      color: 'var(--text-muted)',
      paddingLeft: s.icon ? big ? 0 : 22 : 0
    }
  }, s.label))));
}
Object.assign(__ds_scope, { TrailStats });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trail/TrailStats.jsx", error: String((e && e.message) || e) }); }

// components/trail/TrailCard.jsx
try { (() => {
/**
 * Trail list item — the workhorse of the discovery & saved screens.
 * Composes Card + DifficultyPill + TrailStats + Badge. A map-texture
 * thumbnail is generated when no `image` URL is given.
 */
function TrailCard({
  name,
  location,
  difficulty = 'easy',
  stats = [],
  open = true,
  saved = false,
  onToggleSave,
  image = null,
  onClick,
  style = {}
}) {
  const thumb = image ? {
    backgroundImage: `url(${image})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center'
  } : {
    background: 'var(--terrain-park)',
    backgroundImage: 'radial-gradient(120% 80% at 80% 120%, var(--verde-200) 0%, transparent 55%), repeating-radial-gradient(closest-side at 30% 40%, transparent 0 16px, rgba(25,79,57,0.08) 16px 18px)'
  };
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    interactive: !!onClick,
    padding: "none",
    onClick: onClick,
    style: {
      overflow: 'hidden',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 132,
      ...thumb
    }
  }, !image && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--verde-300)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "map",
    style: {
      width: 30,
      height: 30
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 12,
      left: 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: open ? 'success' : 'danger',
    dot: true
  }, open ? 'Open' : 'Closed')), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 10,
      right: 10
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    label: saved ? 'Saved' : 'Save trail',
    variant: "float",
    size: "sm",
    onClick: e => {
      e.stopPropagation();
      onToggleSave && onToggleSave();
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "bookmark",
    style: {
      width: 16,
      height: 16,
      fill: saved ? 'var(--accent)' : 'none',
      color: saved ? 'var(--accent)' : 'var(--text-muted)'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 17,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: 0,
      lineHeight: 1.2
    }
  }, name), location && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 5,
      marginTop: 4,
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "map-pin",
    style: {
      width: 13,
      height: 13,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, location))), /*#__PURE__*/React.createElement(__ds_scope.DifficultyPill, {
    level: difficulty,
    size: "sm",
    style: {
      flex: 'none'
    }
  })), stats.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      paddingTop: 14,
      borderTop: '1px solid var(--border-soft)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.TrailStats, {
    stats: stats
  }))));
}
Object.assign(__ds_scope, { TrailCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trail/TrailCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/MapCanvas.jsx
try { (() => {
// MapCanvas — a stylized vector map of the Rio Grande Valley.
// Terrain drawn as SVG; interactive trail pins are HTML overlays on top.
const DIFF_COLOR = {
  easy: 'var(--diff-easy)',
  moderate: 'var(--diff-moderate)',
  hard: 'var(--diff-hard)',
  expert: 'var(--diff-expert)'
};
function MapTerrain() {
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 400 820",
    preserveAspectRatio: "xMidYMid slice",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("rect", {
    width: "400",
    height: "820",
    fill: "var(--terrain-land)"
  }), /*#__PURE__*/React.createElement("g", {
    stroke: "var(--terrain-contour)",
    strokeWidth: "1",
    fill: "none",
    opacity: "0.5"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M-20 120 C 90 70, 200 160, 320 100 S 460 150, 520 110"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M-20 160 C 90 110, 200 200, 320 140 S 460 190, 520 150"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M-20 540 C 110 490, 220 580, 330 520 S 470 560, 520 530"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M-20 580 C 110 530, 220 620, 330 560 S 470 600, 520 570"
  })), /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
    d: "M40 180 C 120 150, 200 175, 230 240 C 250 300, 180 350, 110 340 C 50 330, 10 250, 40 180 Z",
    fill: "var(--terrain-park)",
    stroke: "var(--verde-200)",
    strokeWidth: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M250 430 C 330 410, 390 450, 380 520 C 372 575, 300 600, 250 575 C 205 552, 200 460, 250 430 Z",
    fill: "var(--terrain-park)",
    stroke: "var(--verde-200)",
    strokeWidth: "2"
  })), /*#__PURE__*/React.createElement("path", {
    d: "M150 410 C 200 395, 250 420, 240 450 C 232 475, 180 480, 150 465 C 120 450, 110 423, 150 410 Z",
    fill: "var(--terrain-water)"
  }), /*#__PURE__*/React.createElement("ellipse", {
    cx: "320",
    cy: "250",
    rx: "34",
    ry: "18",
    fill: "var(--terrain-water)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M-20 700 C 80 660, 130 740, 220 705 C 300 675, 340 735, 430 700 L 430 830 L -20 830 Z",
    fill: "var(--terrain-water)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M-20 700 C 80 660, 130 740, 220 705 C 300 675, 340 735, 430 700",
    fill: "none",
    stroke: "var(--resaca-300)",
    strokeWidth: "2",
    opacity: "0.7"
  }), /*#__PURE__*/React.createElement("g", {
    stroke: "var(--arena-0)",
    strokeWidth: "7",
    strokeLinecap: "round",
    fill: "none",
    opacity: "0.9"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M0 300 L 400 330"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M120 0 L 150 820"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M300 0 L 280 650"
  })), /*#__PURE__*/React.createElement("g", {
    stroke: "var(--arena-300)",
    strokeWidth: "1",
    fill: "none",
    opacity: "0.7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M0 300 L 400 330"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M120 0 L 150 820"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M300 0 L 280 650"
  })), /*#__PURE__*/React.createElement("g", {
    stroke: "var(--terrain-trail)",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    fill: "none",
    strokeDasharray: "2 7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M110 250 C 150 230, 180 270, 150 310 C 120 345, 90 300, 110 250 Z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M300 470 C 340 455, 360 500, 330 535 C 300 565, 270 510, 300 470 Z"
  })));
}

// A single map pin (HTML overlay). `compact` shows just the teardrop.
function MapPin({
  x,
  y,
  difficulty = 'easy',
  selected = false,
  label,
  onClick
}) {
  const color = DIFF_COLOR[difficulty] || DIFF_COLOR.easy;
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      position: 'absolute',
      left: `${x}%`,
      top: `${y}%`,
      transform: `translate(-50%, -100%) scale(${selected ? 1.12 : 1})`,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0,
      transition: 'transform var(--dur-base) var(--ease-spring)',
      zIndex: selected ? 5 : 2,
      transformOrigin: 'bottom center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: selected ? 38 : 30,
      height: selected ? 38 : 30,
      borderRadius: '50% 50% 50% 0',
      transform: 'rotate(-45deg)',
      background: selected ? 'var(--accent)' : color,
      border: '2.5px solid var(--arena-0)',
      boxShadow: 'var(--shadow-float)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": selected ? 'tree-pine' : 'circle',
    style: {
      transform: 'rotate(45deg)',
      width: selected ? 17 : 9,
      height: selected ? 17 : 9,
      color: '#fff',
      fill: selected ? 'none' : '#fff'
    }
  })));
}
window.MapTerrain = MapTerrain;
window.MapPin = MapPin;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/MapCanvas.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/data.js
try { (() => {
// Sample Rio Grande Valley parks & trails data for the Sendero UI kit.
// Real RGV locations; stats are illustrative.
window.SENDERO = {
  trails: [{
    id: 'chachalaca',
    name: 'Chachalaca Trail',
    park: 'Santa Ana NWR',
    area: 'Alamo, TX',
    difficulty: 'easy',
    open: true,
    distance: '1.8 mi',
    elevation: '+40 ft',
    time: '0:50',
    species: '120',
    blurb: 'A shaded loop through Tamaulipan thornforest along an old resaca. Best at dawn for plain chachalacas and green jays.',
    amenities: ['Restrooms', 'Parking', 'Wheelchair', 'Bird blind'],
    lat: 26.0750,
    lng: -98.1380
  }, {
    id: 'rio-overlook',
    name: 'Rio Grande Overlook',
    park: 'Bentsen-Rio Grande Valley SP',
    area: 'Mission, TX',
    difficulty: 'moderate',
    open: true,
    distance: '4.2 mi',
    elevation: '+312 ft',
    time: '1:45',
    species: '98',
    blurb: 'Follows the levee to a bend in the Rio Grande with sweeping views into the floodplain. Exposed — bring water.',
    amenities: ['Parking', 'Water', 'Hawk tower', 'Tram'],
    lat: 26.1806,
    lng: -98.3805
  }, {
    id: 'green-jay',
    name: 'Green Jay Trail',
    park: 'Estero Llano Grande SP',
    area: 'Weslaco, TX',
    difficulty: 'easy',
    open: true,
    distance: '2.1 mi',
    elevation: '+25 ft',
    time: '1:00',
    species: '140',
    blurb: 'Boardwalk and shoreline path skirting shallow wetlands. Reliable for roseate spoonbills and least grebes.',
    amenities: ['Restrooms', 'Parking', 'Wheelchair', 'Visitor center'],
    lat: 26.1300,
    lng: -97.9560
  }, {
    id: 'mexican-olive',
    name: 'Mexican Olive Trail',
    park: 'Resaca de la Palma SP',
    area: 'Brownsville, TX',
    difficulty: 'moderate',
    open: true,
    distance: '3.4 mi',
    elevation: '+60 ft',
    time: '1:30',
    species: '110',
    blurb: 'The longest of the resaca loops, winding through dense canopy. Listen for the buff-bellied hummingbird.',
    amenities: ['Parking', 'Water', 'Tram', 'Bike rental'],
    lat: 25.9970,
    lng: -97.5710
  }, {
    id: 'sabal-forest',
    name: 'Forest Trail',
    park: 'Sabal Palm Sanctuary',
    area: 'Brownsville, TX',
    difficulty: 'easy',
    open: false,
    distance: '1.4 mi',
    elevation: '+15 ft',
    time: '0:40',
    species: '95',
    blurb: 'Through one of the last native sabal palm forests in the U.S. Closed after recent storm damage to the boardwalk.',
    amenities: ['Restrooms', 'Parking', 'Bird blind', 'Cafe'],
    lat: 25.8480,
    lng: -97.4170
  }, {
    id: 'lakeside',
    name: 'Lakeside Trail',
    park: 'Laguna Atascosa NWR',
    area: 'Los Fresnos, TX',
    difficulty: 'hard',
    open: true,
    distance: '6.8 mi',
    elevation: '+220 ft',
    time: '3:10',
    species: '160',
    blurb: 'A long, remote loop above the lagoon — ocelot country. Full sun and soft sand; for prepared hikers only.',
    amenities: ['Parking', 'Water', 'Observation deck'],
    lat: 26.2280,
    lng: -97.3540
  }],
  filters: ['Easy', 'Dogs OK', 'Wheelchair', 'Bird hotspot', 'Open now', 'Under 3 mi']
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/data.js", error: String((e && e.message) || e) }); }

// ui_kits/app/ios-frame.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// iOS.jsx — Simplified iOS 26 (Liquid Glass) device frame
// Based on the iOS 26 UI Kit + Figma status bar spec. No assets, no deps.
// Exports (to window): IOSDevice, IOSStatusBar, IOSNavBar, IOSGlassPill, IOSList, IOSListRow, IOSKeyboard
//
// Usage — wrap your screen content in <IOSDevice> to get the bezel, status bar
// and home indicator (props: title, dark, keyboard):
//
//   <IOSDevice title="Settings">
//     ...your screen content...
//   </IOSDevice>
//   <IOSDevice dark title="Search" keyboard>…</IOSDevice>
/* END USAGE */

// ─────────────────────────────────────────────────────────────
// Status bar
// ─────────────────────────────────────────────────────────────
function IOSStatusBar({
  dark = false,
  time = '9:41'
}) {
  const c = dark ? '#fff' : '#000';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 154,
      alignItems: 'center',
      justifyContent: 'center',
      padding: '21px 24px 19px',
      boxSizing: 'border-box',
      position: 'relative',
      zIndex: 20,
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 1.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: '-apple-system, "SF Pro", system-ui',
      fontWeight: 590,
      fontSize: 17,
      lineHeight: '22px',
      color: c
    }
  }, time)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 7,
      paddingTop: 1,
      paddingRight: 1
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "19",
    height: "12",
    viewBox: "0 0 19 12"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "7.5",
    width: "3.2",
    height: "4.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "4.8",
    y: "5",
    width: "3.2",
    height: "7",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9.6",
    y: "2.5",
    width: "3.2",
    height: "9.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14.4",
    y: "0",
    width: "3.2",
    height: "12",
    rx: "0.7",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "12",
    viewBox: "0 0 17 12"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z",
    fill: c
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8.5",
    cy: "10.5",
    r: "1.5",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "27",
    height: "13",
    viewBox: "0 0 27 13"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "23",
    height: "12",
    rx: "3.5",
    stroke: c,
    strokeOpacity: "0.35",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "20",
    height: "9",
    rx: "2",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z",
    fill: c,
    fillOpacity: "0.4"
  }))));
}

// ─────────────────────────────────────────────────────────────
// Liquid glass pill — blur + tint + shine
// ─────────────────────────────────────────────────────────────
function IOSGlassPill({
  children,
  dark = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      minWidth: 44,
      borderRadius: 9999,
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: dark ? '0 2px 6px rgba(0,0,0,0.35), 0 6px 16px rgba(0,0,0,0.2)' : '0 1px 3px rgba(0,0,0,0.07), 0 3px 10px rgba(0,0,0,0.06)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.28)' : 'rgba(255,255,255,0.5)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15), inset -1px -1px 1px rgba(255,255,255,0.08)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      display: 'flex',
      alignItems: 'center',
      padding: '0 4px'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Navigation bar — glass pills + large title
// ─────────────────────────────────────────────────────────────
function IOSNavBar({
  title = 'Title',
  dark = false,
  trailingIcon = true
}) {
  const muted = dark ? 'rgba(255,255,255,0.6)' : '#404040';
  const text = dark ? '#fff' : '#000';
  const pillIcon = content => /*#__PURE__*/React.createElement(IOSGlassPill, {
    dark: dark
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, content));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      paddingTop: 62,
      paddingBottom: 10,
      position: 'relative',
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 16px'
    }
  }, pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "20",
    viewBox: "0 0 12 20",
    fill: "none",
    style: {
      marginLeft: -1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10 2L2 10l8 8",
    stroke: muted,
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), trailingIcon && pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "6",
    viewBox: "0 0 22 6"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "3",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "19",
    cy: "3",
    r: "2.5",
    fill: muted
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      fontFamily: '-apple-system, system-ui',
      fontSize: 34,
      fontWeight: 700,
      lineHeight: '41px',
      color: text,
      letterSpacing: 0.4
    }
  }, title));
}

// ─────────────────────────────────────────────────────────────
// Grouped list (inset card, r:26) + row (52px)
// ─────────────────────────────────────────────────────────────
function IOSListRow({
  title,
  detail,
  icon,
  chevron = true,
  isLast = false,
  dark = false
}) {
  const text = dark ? '#fff' : '#000';
  const sec = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const ter = dark ? 'rgba(235,235,245,0.3)' : 'rgba(60,60,67,0.3)';
  const sep = dark ? 'rgba(84,84,88,0.65)' : 'rgba(60,60,67,0.12)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      minHeight: 52,
      padding: '0 16px',
      position: 'relative',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      letterSpacing: -0.43
    }
  }, icon && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 7,
      background: icon,
      marginRight: 12,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      color: text
    }
  }, title), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      color: sec,
      marginRight: 6
    }
  }, detail), chevron && /*#__PURE__*/React.createElement("svg", {
    width: "8",
    height: "14",
    viewBox: "0 0 8 14",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 1l6 6-6 6",
    stroke: ter,
    strokeWidth: "2",
    fill: "none",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })), !isLast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      right: 0,
      left: icon ? 58 : 16,
      height: 0.5,
      background: sep
    }
  }));
}
function IOSList({
  header,
  children,
  dark = false
}) {
  const hc = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const bg = dark ? '#1C1C1E' : '#fff';
  return /*#__PURE__*/React.createElement("div", null, header && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: '-apple-system, system-ui',
      fontSize: 13,
      color: hc,
      textTransform: 'uppercase',
      padding: '8px 36px 6px',
      letterSpacing: -0.08
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      borderRadius: 26,
      margin: '0 16px',
      overflow: 'hidden'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Device frame
// ─────────────────────────────────────────────────────────────
function IOSDevice({
  children,
  width = 402,
  height = 874,
  dark = false,
  title,
  keyboard = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      height,
      borderRadius: 48,
      overflow: 'hidden',
      position: 'relative',
      background: dark ? '#000' : '#F2F2F7',
      boxShadow: '0 40px 80px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.12)',
      fontFamily: '-apple-system, system-ui, sans-serif',
      WebkitFontSmoothing: 'antialiased'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 11,
      left: '50%',
      transform: 'translateX(-50%)',
      width: 126,
      height: 37,
      borderRadius: 24,
      background: '#000',
      zIndex: 50
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement(IOSStatusBar, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column'
    }
  }, title !== undefined && /*#__PURE__*/React.createElement(IOSNavBar, {
    title: title,
    dark: dark
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto'
    }
  }, children), keyboard && /*#__PURE__*/React.createElement(IOSKeyboard, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      zIndex: 60,
      height: 34,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-end',
      paddingBottom: 8,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 139,
      height: 5,
      borderRadius: 100,
      background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)'
    }
  })));
}

// ─────────────────────────────────────────────────────────────
// Keyboard — iOS 26 liquid glass
// ─────────────────────────────────────────────────────────────
function IOSKeyboard({
  dark = false
}) {
  const glyph = dark ? 'rgba(255,255,255,0.7)' : '#595959';
  const sugg = dark ? 'rgba(255,255,255,0.6)' : '#333';
  const keyBg = dark ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.85)';

  // special-key icons
  const icons = {
    shift: /*#__PURE__*/React.createElement("svg", {
      width: "19",
      height: "17",
      viewBox: "0 0 19 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M9.5 1L1 9.5h4.5V16h8V9.5H18L9.5 1z",
      fill: glyph
    })),
    del: /*#__PURE__*/React.createElement("svg", {
      width: "23",
      height: "17",
      viewBox: "0 0 23 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M7 1h13a2 2 0 012 2v11a2 2 0 01-2 2H7l-6-7.5L7 1z",
      fill: "none",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinejoin: "round"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10 5l7 7M17 5l-7 7",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinecap: "round"
    })),
    ret: /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "14",
      viewBox: "0 0 20 14"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M18 1v6H4m0 0l4-4M4 7l4 4",
      fill: "none",
      stroke: "#fff",
      strokeWidth: "1.8",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }))
  };
  const key = (content, {
    w,
    flex,
    ret,
    fs = 25,
    k
  } = {}) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      height: 42,
      borderRadius: 8.5,
      flex: flex ? 1 : undefined,
      width: w,
      minWidth: 0,
      background: ret ? '#08f' : keyBg,
      boxShadow: '0 1px 0 rgba(0,0,0,0.075)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: '-apple-system, "SF Compact", system-ui',
      fontSize: fs,
      fontWeight: 458,
      color: ret ? '#fff' : glyph
    }
  }, content);
  const row = (keys, pad = 0) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      justifyContent: 'center',
      padding: `0 ${pad}px`
    }
  }, keys.map(l => key(l, {
    flex: true,
    k: l
  })));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 15,
      borderRadius: 27,
      overflow: 'hidden',
      padding: '11px 0 2px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      boxShadow: dark ? '0 -2px 20px rgba(0,0,0,0.09)' : '0 -1px 6px rgba(0,0,0,0.018), 0 -3px 20px rgba(0,0,0,0.012)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.14)' : 'rgba(255,255,255,0.25)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center',
      padding: '8px 22px 13px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, ['"The"', 'the', 'to'].map((w, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 25,
      background: '#ccc',
      opacity: 0.3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      color: sugg,
      letterSpacing: -0.43,
      lineHeight: '22px'
    }
  }, w)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 13,
      padding: '0 6.5px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, row(['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p']), row(['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'], 20), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14.25,
      alignItems: 'center'
    }
  }, key(icons.shift, {
    w: 45,
    k: 'shift'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      flex: 1
    }
  }, ['z', 'x', 'c', 'v', 'b', 'n', 'm'].map(l => key(l, {
    flex: true,
    k: l
  }))), key(icons.del, {
    w: 45,
    k: 'del'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, key('ABC', {
    w: 92.25,
    fs: 18,
    k: 'abc'
  }), key('', {
    flex: true,
    k: 'space'
  }), key(icons.ret, {
    w: 92.25,
    ret: true,
    k: 'ret'
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 56,
      width: '100%',
      position: 'relative'
    }
  }));
}
Object.assign(window, {
  IOSDevice,
  IOSStatusBar,
  IOSNavBar,
  IOSGlassPill,
  IOSList,
  IOSListRow,
  IOSKeyboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/ios-frame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/screens.jsx
try { (() => {
// Sendero app screens. Composes design-system components (window.<NS>) with
// the local MapTerrain / MapPin. All screens are presentational; routing lives
// in index.html.
const NS = window.SenderoDesignSystem_139929;
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Input,
  SearchField,
  SegmentedControl,
  DifficultyPill,
  TrailStats,
  TrailCard,
  BottomNav
} = NS;
const Ico = (n, style) => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n,
  style: style
});
const STATUS_PAD = 56; // clears the status bar / dynamic island

// ── shared bits ──────────────────────────────────────────────
function statsFor(t, withLabels) {
  return [{
    icon: Ico('route'),
    value: t.distance,
    label: withLabels ? 'Distance' : undefined
  }, {
    icon: Ico('trending-up'),
    value: t.elevation,
    label: withLabels ? 'Elev gain' : undefined
  }, {
    icon: Ico('clock'),
    value: t.time,
    label: withLabels ? 'Est time' : undefined
  }];
}
function SectionHead({
  title,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      margin: '0 0 12px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 19,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: 0
    }
  }, title), action && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-link)'
    }
  }, action));
}

// ── Explore ──────────────────────────────────────────────────
function ExploreScreen({
  trails,
  saved,
  onToggleSave,
  onOpen,
  filters,
  activeFilters,
  onFilter
}) {
  const featured = trails[1];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: `${STATUS_PAD}px 20px 12px`,
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-soft)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--text-muted)',
      display: 'flex',
      alignItems: 'center',
      gap: 4
    }
  }, Ico('map-pin', {
    width: 13,
    height: 13
  }), " Rio Grande Valley"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 26,
      fontWeight: 800,
      color: 'var(--text-strong)',
      margin: '2px 0 0',
      letterSpacing: '-0.02em'
    }
  }, "Explore")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      borderRadius: '50%',
      background: 'var(--verde-100)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--verde-700)',
      fontWeight: 700,
      border: '1.5px solid var(--verde-200)'
    }
  }, "RC")), /*#__PURE__*/React.createElement(SearchField, {
    placeholder: "Search parks & trails",
    elevated: false
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto',
      padding: '16px 20px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      overflowX: 'auto',
      paddingBottom: 18,
      margin: '0 -20px',
      padding: '0 20px 18px'
    }
  }, filters.map(f => /*#__PURE__*/React.createElement(Tag, {
    key: f,
    selected: activeFilters.includes(f),
    onClick: () => onFilter(f),
    style: {
      flex: 'none'
    }
  }, f))), /*#__PURE__*/React.createElement(SectionHead, {
    title: "Featured this week"
  }), /*#__PURE__*/React.createElement(Card, {
    padding: "none",
    interactive: true,
    onClick: () => onOpen(featured.id),
    style: {
      overflow: 'hidden',
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 170,
      background: 'var(--verde-700)',
      backgroundImage: 'radial-gradient(140% 120% at 70% 130%, var(--verde-500) 0%, transparent 60%)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      opacity: 0.5,
      backgroundImage: 'repeating-radial-gradient(closest-side at 35% 30%, transparent 0 22px, rgba(255,255,255,0.08) 22px 24px)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 16,
      bottom: 16,
      right: 16,
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "accent",
    style: {
      marginBottom: 8
    }
  }, "Editor's pick"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 24,
      fontWeight: 800,
      letterSpacing: '-0.02em',
      lineHeight: 1.1
    }
  }, featured.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      opacity: 0.85,
      marginTop: 2
    }
  }, featured.park)))), /*#__PURE__*/React.createElement(SectionHead, {
    title: "Trails near you",
    action: "See all"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, trails.map(t => /*#__PURE__*/React.createElement(TrailCard, {
    key: t.id,
    name: t.name,
    location: t.park,
    difficulty: t.difficulty,
    open: t.open,
    saved: saved.includes(t.id),
    onToggleSave: () => onToggleSave(t.id),
    onClick: () => onOpen(t.id),
    stats: statsFor(t, false)
  })))));
}

// ── Map ──────────────────────────────────────────────────────
const PIN_POS = {
  chachalaca: {
    x: 24,
    y: 32
  },
  'rio-overlook': {
    x: 68,
    y: 24
  },
  'green-jay': {
    x: 44,
    y: 52
  },
  'mexican-olive': {
    x: 78,
    y: 62
  },
  'sabal-forest': {
    x: 30,
    y: 70
  },
  lakeside: {
    x: 60,
    y: 44
  }
};
function MapScreen({
  trails,
  saved,
  onToggleSave,
  onOpen
}) {
  const [selId, setSelId] = React.useState('green-jay');
  const sel = trails.find(t => t.id === selId);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      position: 'relative',
      overflow: 'hidden',
      background: 'var(--terrain-land)'
    }
  }, /*#__PURE__*/React.createElement(MapTerrain, null), trails.map(t => {
    const p = PIN_POS[t.id];
    if (!p) return null;
    return /*#__PURE__*/React.createElement(MapPin, {
      key: t.id,
      x: p.x,
      y: p.y,
      difficulty: t.difficulty,
      selected: t.id === selId,
      onClick: () => setSelId(t.id)
    });
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: STATUS_PAD,
      left: 16,
      right: 16,
      zIndex: 8
    }
  }, /*#__PURE__*/React.createElement(SearchField, {
    placeholder: "Search this area"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: STATUS_PAD + 60,
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 8
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    value: "map",
    onChange: () => {},
    options: [{
      value: 'map',
      label: 'Map',
      icon: Ico('map', {
        width: 15,
        height: 15
      })
    }, {
      value: 'list',
      label: 'List',
      icon: Ico('list', {
        width: 15,
        height: 15
      })
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 16,
      top: STATUS_PAD + 120,
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      zIndex: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-float)'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    label: "Zoom in",
    variant: "float",
    style: {
      borderRadius: 0,
      boxShadow: 'none'
    }
  }, Ico('plus', {
    width: 18,
    height: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-soft)'
    }
  }), /*#__PURE__*/React.createElement(IconButton, {
    label: "Zoom out",
    variant: "float",
    style: {
      borderRadius: 0,
      boxShadow: 'none'
    }
  }, Ico('minus', {
    width: 18,
    height: 18
  }))), /*#__PURE__*/React.createElement(IconButton, {
    label: "Map layers",
    variant: "float"
  }, Ico('layers', {
    width: 18,
    height: 18
  })), /*#__PURE__*/React.createElement(IconButton, {
    label: "Locate me",
    variant: "solid",
    round: true
  }, Ico('locate-fixed', {
    width: 18,
    height: 18
  }))), sel && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 12,
      right: 12,
      bottom: 18,
      zIndex: 9
    }
  }, /*#__PURE__*/React.createElement(Card, {
    elevation: "lg",
    padding: "md",
    interactive: true,
    onClick: () => onOpen(sel.id)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 70,
      height: 70,
      borderRadius: 'var(--radius-md)',
      flex: 'none',
      background: 'var(--terrain-park)',
      backgroundImage: 'radial-gradient(120% 100% at 70% 120%, var(--verde-200) 0%, transparent 60%)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--verde-400)'
    }
  }, Ico('mountain-snow', {
    width: 24,
    height: 24
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: 0
    }
  }, sel.name), /*#__PURE__*/React.createElement(DifficultyPill, {
    level: sel.difficulty,
    size: "sm",
    showBars: false,
    style: {
      flex: 'none'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-muted)',
      margin: '3px 0 8px'
    }
  }, sel.park, " \xB7 ", sel.area), /*#__PURE__*/React.createElement(TrailStats, {
    stats: statsFor(sel, false)
  }))))));
}

// ── Trail detail ─────────────────────────────────────────────
function TrailDetail({
  trail,
  saved,
  onToggleSave,
  onBack
}) {
  const t = trail;
  const isSaved = saved.includes(t.id);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 260,
      background: 'var(--verde-800)',
      backgroundImage: 'radial-gradient(130% 120% at 75% 120%, var(--verde-600) 0%, transparent 60%)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      opacity: 0.45,
      backgroundImage: 'repeating-radial-gradient(closest-side at 30% 35%, transparent 0 26px, rgba(255,255,255,0.08) 26px 28px)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: STATUS_PAD - 8,
      left: 16,
      right: 16,
      display: 'flex',
      justifyContent: 'space-between',
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    label: "Back",
    variant: "float",
    round: true,
    onClick: onBack
  }, Ico('arrow-left', {
    width: 18,
    height: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    label: "Share",
    variant: "float",
    round: true
  }, Ico('share-2', {
    width: 17,
    height: 17
  })), /*#__PURE__*/React.createElement(IconButton, {
    label: isSaved ? 'Saved' : 'Save',
    variant: "float",
    round: true,
    onClick: () => onToggleSave(t.id)
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "bookmark",
    style: {
      width: 17,
      height: 17,
      color: isSaved ? 'var(--accent)' : 'var(--text-muted)',
      fill: isSaved ? 'var(--accent)' : 'none'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 20,
      bottom: 18,
      right: 20,
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: t.open ? 'success' : 'danger',
    dot: true
  }, t.open ? 'Open today' : 'Temporarily closed'), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 30,
      fontWeight: 800,
      letterSpacing: '-0.02em',
      margin: '10px 0 0',
      lineHeight: 1.05
    }
  }, t.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 5,
      fontSize: 14,
      opacity: 0.9,
      marginTop: 4
    }
  }, Ico('map-pin', {
    width: 14,
    height: 14
  }), " ", t.park, " \xB7 ", t.area))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 120px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(DifficultyPill, {
    level: t.difficulty
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 5,
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, Ico('bird', {
    width: 15,
    height: 15
  }), " ", /*#__PURE__*/React.createElement("span", {
    className: "mono-stat",
    style: {
      fontWeight: 700,
      color: 'var(--text-body)'
    }
  }, t.species), " species logged")), /*#__PURE__*/React.createElement(Card, {
    padding: "md",
    style: {
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement(TrailStats, {
    size: "lg",
    stats: statsFor(t, true)
  })), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 17,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 8px'
    }
  }, "About this trail"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--text-body)',
      margin: '0 0 22px'
    }
  }, t.blurb), !t.open && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      padding: 14,
      background: 'var(--danger-soft)',
      border: '1px solid var(--red-700)',
      borderRadius: 'var(--radius-md)',
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "triangle-alert",
    style: {
      width: 18,
      height: 18,
      color: 'var(--danger)',
      flex: 'none',
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      color: 'var(--red-700)',
      lineHeight: 1.5
    }
  }, "Boardwalk closed for storm repairs. Check the park office before visiting.")), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 17,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 12px'
    }
  }, "Amenities"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, t.amenities.map(a => /*#__PURE__*/React.createElement(Tag, {
    key: a,
    icon: Ico('check', {
      width: 14,
      height: 14
    })
  }, a))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      padding: '14px 20px calc(14px + 18px)',
      background: 'var(--surface-card)',
      borderTop: '1px solid var(--border-soft)',
      display: 'flex',
      gap: 12,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    leadingIcon: Ico('navigation', {
      width: 17,
      height: 17
    })
  }, "Directions"), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    fullWidth: true,
    leadingIcon: Ico('footprints', {
      width: 18,
      height: 18
    }),
    disabled: !t.open
  }, "Start hike")));
}

// ── Saved ────────────────────────────────────────────────────
function SavedScreen({
  trails,
  saved,
  onToggleSave,
  onOpen
}) {
  const list = trails.filter(t => saved.includes(t.id));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: `${STATUS_PAD}px 20px 14px`,
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-soft)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 26,
      fontWeight: 800,
      color: 'var(--text-strong)',
      margin: 0,
      letterSpacing: '-0.02em'
    }
  }, "Saved"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, list.length, " trail", list.length === 1 ? '' : 's', " on your list")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto',
      padding: '16px 20px 24px'
    }
  }, list.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '80px 30px',
      color: 'var(--text-muted)'
    }
  }, Ico('bookmark', {
    width: 34,
    height: 34
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      marginTop: 12
    }
  }, "Tap the bookmark on any trail to save it here for offline.")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, list.map(t => /*#__PURE__*/React.createElement(TrailCard, {
    key: t.id,
    name: t.name,
    location: t.park,
    difficulty: t.difficulty,
    open: t.open,
    saved: true,
    onToggleSave: () => onToggleSave(t.id),
    onClick: () => onOpen(t.id),
    stats: statsFor(t, false)
  })))));
}
Object.assign(window, {
  ExploreScreen,
  MapScreen,
  TrailDetail,
  SavedScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.SearchField = __ds_scope.SearchField;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.BottomNav = __ds_scope.BottomNav;

__ds_ns.DifficultyPill = __ds_scope.DifficultyPill;

__ds_ns.TrailCard = __ds_scope.TrailCard;

__ds_ns.TrailStats = __ds_scope.TrailStats;

})();
